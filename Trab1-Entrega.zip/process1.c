// Grupo : Pedro Augusto (0520253) e Lucas Menezes (1310844)
// PROCESS 1
#include <stdio.h>

int main (void)
{
	int i,x;
	int j,z,a;
	printf ("inicio do processo 1\n");
	for (z=1;z<10;z++)	
	{
		puts("Pedro");
		for (a=1;a<100;a++)
		{	
		
			for (j=1;j<1000;j++)	
			{
				for (i=1;i<10000;i++)
				{
					x= i*i*i*i;
				}
			}
		}
	}			
	printf ("termino do processo 1\n");
	return 1;
}
